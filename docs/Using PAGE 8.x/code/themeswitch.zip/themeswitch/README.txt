README.txt

This folder contains the code to the "Changing the themes in your application" in the "Using PAGE 8.x" document
