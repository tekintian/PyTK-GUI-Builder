README.txt

This folder contains the code to the "TNotebook Tab Positions" section in the "Using PAGE 8.x" document.
