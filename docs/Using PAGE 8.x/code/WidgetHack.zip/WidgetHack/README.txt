README.txt

This folder contains the code to the "WidgetHack" section in the "Using PAGE 8.x" document.
